
// Service removed.
export const FirestoreService = {
    getDB: () => null,
    syncNote: async (_note: any) => {},
    fetchAllNotes: async () => []
};